<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "<a href="http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd</a>">
<html xmlns="<a href="http://www.w3.org/1999/xhtml">http://www.w3.org/1999/xhtml</a>">
<head>
<title>CSS使背景颜色渐变--柯乐义</title>
<style type="text/css">
        body {color:white;
                background:url("bg.png");
                background-position: center 100%; background-repeat: no-repeat;background-size:cover;
            }
</style></head>
<body>
用CSS是div颜色渐变
从绿到红
keleyi.com
</body>
</html>